package com.example.snakegame.Enums;

public enum TitleType {
    Nothing,
    Wall,
    Crossing,
    SnakeHead,
    SnakeTail,
    Apple;


}
