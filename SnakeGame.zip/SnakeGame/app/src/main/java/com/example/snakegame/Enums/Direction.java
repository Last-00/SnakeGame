package com.example.snakegame.Enums;

public enum Direction {
    North,
    East,
    South,
    West
}
