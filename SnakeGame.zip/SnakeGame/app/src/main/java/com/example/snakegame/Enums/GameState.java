package com.example.snakegame.Enums;

public enum GameState {
    Running,
    Lost;
}
